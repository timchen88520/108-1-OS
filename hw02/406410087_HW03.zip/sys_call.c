#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char** argv) {
    char buf[10] = {0};
    long ret;

    printf("使用 'syscall' 呼叫system call\n");
    printf("請輸入一個字元\n");
    __asm__ volatile (
        "mov $0, %%rax\n"   //system call number
        "mov $0, %%rdi\n"   //read from stdin
        "mov %1, %%rsi\n"   //buffer
        "mov $1, %%rdx\n"   //read size of string
        "syscall\n"
        "mov %%rax, %0"
        :  "=m"(ret)
        : "g" (buf)
        : "rax", "rdi", "rsi", "rdx");
    printf("回傳值是：%ld\n", ret);
    printf("您輸入的字元是:%s\n", buf);
    return 0;
}
